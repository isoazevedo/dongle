<?php

require_once('./phpagi/phpagi_asmanager.php');

$manager_host = '127.0.0.1';	        // IP DO SERVIDOR ASTERISK
$manager_user = 'dongle' ;		// USUARIO MANAGER.CONF
$manager_pass = 'dongle!@#';		// SENHA MANAGER.CONF

?>
